#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <filesystem>
#include <cstdio> // Biblioteca para a função remove
#include <unordered_map>
#include <iomanip>

void processChgFile(const std::string& filename) {
    std::ifstream infile(filename);
    std::ofstream atomsFile("charges_atoms.log");
    std::ofstream estrcFile("xyz.log");

    if (!infile.is_open() || !atomsFile.is_open() || !estrcFile.is_open()) {
        std::cerr << "Erro ao abrir arquivo(s)." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(infile, line)) {
        std::istringstream iss(line);
        std::string atom, value;
        

        // Ler a primeira coluna (átomo)
        if (!(iss >> atom)) {
            std::cerr << "Erro ao ler o átomo da linha: " << line << std::endl;
            continue; // Ignora a linha se não conseguir ler
        }

        // Ler as colunas intermediárias
        std::vector<std::string> values;
        for (int i = 0; i < 3; ++i) { // Lê as colunas 2, 3 e 4
            if (!(iss >> value)) {
                std::cerr << "Erro ao ler valor da linha: " << line << std::endl;
                break;
            }
            values.push_back(value);
        }

        // Ler a quinta coluna
        if (!(iss >> value)) {
            std::cerr << "Erro ao ler a quinta coluna da linha: " << line << std::endl;
            continue; // Ignora a linha se não conseguir ler
        }

        // Escrever no arquivo de átomos (primeira e quinta coluna)
        atomsFile << atom << " " << value << std::endl;

        // Escrever no arquivo estrc (colunas 2, 3 e 4)
        if (values.size() == 3) {
            estrcFile << values[0] << " " << values[1] << " " << values[2] << std::endl;
        } else {
            std::cerr << "Número de colunas inválido na linha: " << line << std::endl;
        }
    }

    infile.close();
    atomsFile.close();
    estrcFile.close();

    // Apagar o arquivo .chg após o processamento
    std::filesystem::remove(filename);
}

//montar output.pqr
struct Atom {
    int index;
    std::string type;
    double x, y, z, charge, volume;
};

std::unordered_map<std::string, double> atomVolumes = {
    {"H", 1.2},
    {"C", 1.7},
    {"N", 1.55},
    {"O", 1.47},
    {"Li", 1.82},
    {"Be", 1.53},
    {"Na", 2.27},
    {"Mg", 1.73},
    {"K", 2.75},
    {"Ca", 2.31},
    {"Rb", 3.03},
    {"Cs", 3.43},
    {"Sr", 2.49},
    {"Ba", 2.68},
    {"Sc", 2.11},
    {"Ni", 1.63},
    {"Cu", 1.40},
    {"Zn", 1.39},
    {"Pd", 1.63},
    {"Ag", 1.72},
    {"Cd", 1.58},
    {"Pt", 1.75},
    {"Au", 1.66},
    {"Hg", 1.55},
    {"He", 1.4},
    {"Ne", 1.54},
    {"Ar", 1.88},
    {"Kr", 2.02},
    {"Xe", 2.16},
    {"Rn", 2.83},
    {"B", 1.92},
    {"F", 1.47},
    {"Al", 1.84},
    {"Si", 2.1},
    {"P", 1.8},
    {"S", 1.8},
    {"Cl", 1.75},
    {"Ga", 1.87},
    {"Ge", 2.11},
    {"As", 1.85},
    {"Se", 1.9},
    {"Br", 1.85},
    {"In", 1.93},
    {"Sn", 2.17},
    {"Sb", 2.06},
    {"Te", 2.06},
    {"I", 1.98},
    {"Tl", 1.96},
    {"Pb", 2.02},
    {"Bi", 2.2},
    {"Po", 3.48},
    {"Rn", 2.83},
    {"U", 1.86},
};

std::vector<std::string> split(const std::string &s, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

int main() {
    // Percorre os arquivos na pasta atual
    for (const auto& entry : std::filesystem::directory_iterator(".")) {
        if (entry.path().extension() == ".chg") {
            processChgFile(entry.path().string());
        }
    }

//criar pqr
    std::ifstream xyzFile("xyz.log");
    std::ifstream cargaFile("charges_atoms.log");
    std::ofstream outputFile4("output.pqr");



    if (!xyzFile.is_open() || !cargaFile.is_open() || !outputFile4.is_open()) {
        std::cerr << "Error 88 opening files!" << std::endl;
        return 1;
    }

    std::string line;
    std::vector<Atom> atoms;

    // Read carga_e_atomos.log to get atom types and charges
    while (std::getline(cargaFile, line)) {
        std::vector<std::string> tokens = split(line, ' ');
        Atom atom;
        atom.type = tokens[0];
        atom.charge = std::stod(tokens[1]);
        atoms.push_back(atom);
    }

    // Read xyz.log to get coordinates
    size_t index = 0;
    while (std::getline(xyzFile, line)) {
        std::vector<std::string> tokens = split(line, ' ');
        atoms[index].x = std::stod(tokens[0]);
        atoms[index].y = std::stod(tokens[1]);
        atoms[index].z = std::stod(tokens[2]);
        atoms[index].index = index + 1;
        atoms[index].volume = atomVolumes[atoms[index].type];
        index++;
    }

   // Write to output.pqr with formatted output
    for (const auto &atom : atoms) {
        outputFile4 << "ATOM\t"
                   << std::setw(4) << atom.index << "\t"
                   << std::setw(2) << atom.type << "\t"
                   << "LIG\t1\t"
                   << std::setw(10) << std::fixed << std::setprecision(6) << atom.x << "\t"
                   << std::setw(10) << std::fixed << std::setprecision(6) << atom.y << "\t"
                   << std::setw(10) << std::fixed << std::setprecision(6) << atom.z << "\t"
                   << std::setw(10) << std::fixed << std::setprecision(6) << atom.charge << "\t"
                   << std::setw(4) << std::fixed << std::setprecision(2) << atom.volume << std::endl;
    }

    xyzFile.close();
    cargaFile.close();
    outputFile4.close();

    
    system("./converter_files/nomeador");

    return 0;
}
