#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <filesystem>

int main(int argc, char* argv[]) {
    // Verifica se o usuário forneceu um nome de arquivo
    if (argc != 2) {
        std::cerr << "Uso: ./executormtf <nome_do_arquivo>" << std::endl;
        return 1;
    }

    // O nome do arquivo é o segundo argumento
    const char* filename = argv[1];

    // Comando para executar o Multiwfn sem interface gráfica com o arquivo de entrada
    std::string command = "./converter_files/Multiwfn_noGUI ";
    command += filename;

    // Usando popen para abrir um pipe com o programa Multiwfn (comentado por enquanto)
    FILE* pipe = popen((command + " > /dev/null 2>&1").c_str(), "w");

    if (!pipe) {
        perror("Falha ao executar o Multiwfn");
        return 1;
    }

    // Enviando as opções automaticamente
    fprintf(pipe, "7\n");  // Seleciona 'Population analysis and atomic charges'
    fprintf(pipe, "13\n"); // Seleciona 'CHELPG ESP fitting atomic charge'
    fprintf(pipe, "1\n");  // Inicia o cálculo das cargas
    fprintf(pipe, "y\n");  // Confirma a gravação do arquivo de saída

    // Fecha o pipe
    pclose(pipe);

    //executa o converter_orca

    system("./converter_files/converter_orca");


    return 0;
}

