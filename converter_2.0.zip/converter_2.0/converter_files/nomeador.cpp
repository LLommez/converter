#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

int main() {
        // Obtém o caminho do diretório onde o executável está
    fs::path exePath = fs::current_path() / "converter_files";
    fs::path searchDir = exePath.parent_path(); // Pasta anterior a "converter_files"
    fs::path filePath = searchDir / "output.pqr";

    // Verifica se o arquivo output.pqr existe
    if (fs::exists(filePath)) {
        //std::cout << "Arquivo 'output.pqr' encontrado.\n";
        
        std::string newFileName;
        std::cout << "Type the name for your .pqr: ";
        std::getline(std::cin, newFileName);

        fs::path newFilePath = searchDir / (newFileName + ".pqr");

        // Renomeia o arquivo
        try {
            fs::rename(filePath, newFilePath);
            std::cout << "Pqr successfully renamed to " << newFileName << ".\n";
        } catch (const fs::filesystem_error& e) {
            std::cerr << "Erro 32: " << e.what() << '\n';
        }
    } else {
        std::cout << "Erro 56.\n";
    }

    return 0;
}
