#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib> // Para usar o system()

void executeConverter(const std::string &converter, const std::string &file) {
    // O comando será executado no formato "./converter_gaussian nome_do_arquivo"
    std::string command = "./" + converter + " " + file;
    system(command.c_str());
}

void listFiles() {
    std::cout << "Files available in the folder:\n";
    system("ls"); // Comando para listar os arquivos
}

std::vector<std::string> splitFiles(const std::string &input) {
    std::vector<std::string> files;
    std::istringstream iss(input);
    std::string file;
    while (iss >> file) {
        files.push_back(file);
    }
    return files;
}

int main() {
    std::cout << "-----Welcome to converter!-----" << std::endl;
    std::cout << "--------By Lucca Lommez--------" << std::endl;

    std::string filenamesInput;
    int choice;

    // Passo 1: Listar os arquivos disponíveis
    listFiles();

    // Passo 2: Solicitar que o usuário insira os nomes dos arquivos (que estarão na mesma pasta do programa)
    std::cout << "Type the names of the files to be loaded (separated by space): ";
    std::getline(std::cin, filenamesInput);

    // Armazenar os nomes dos arquivos em um vetor
    std::vector<std::string> files = splitFiles(filenamesInput);

    // Confirmar os arquivos carregados
    std::cout << "Files loaded successfully:\n";
    for (const auto &file : files) {
        std::cout << "- " << file << std::endl;
    }

    // Passo 3: Oferecer opções para o usuário
    std::cout << "Choose an option:\n";
    std::cout << "1 - Input Gaussian\n";
    std::cout << "2 - Input Orca\n";
    std::cout << "Type your choice: ";
    std::cin >> choice;

    // Passo 4: Executar o programa para cada arquivo na fila
    std::string converterPath = "./converter_files/"; // Caminho para a pasta onde estão os executáveis
    for (const auto &file : files) {
        switch (choice) {
            case 1:
                executeConverter(converterPath + "converter_gaussian", file);
                break;
            case 2:
                executeConverter(converterPath + "executormtf", file);
                break;
            default:
                std::cout << "Invalid choice!" << std::endl;
                return 1; // Saída com erro
        }
    }

    return 0;
}

